const mysql = require('mysql2');

// 🔌 สร้างการเชื่อมต่อกับ MySQL
const db = mysql.createConnection({
    host: 'localhost',      // หรือชื่อ host ของ shared host
    user: 'root',
    password: '',
    database: 'moneyflow'
});

// ✅ ทดสอบการเชื่อมต่อ
db.connect((err) => {
    if (err) throw err;
    console.log('Connected to MySQL');
});

module.exports = db;
