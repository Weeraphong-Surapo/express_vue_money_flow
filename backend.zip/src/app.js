const express = require('express');
const cors = require('cors'); // Import cors
const app = express();
const bodyParser = require('body-parser');
const morgan = require("morgan")
const userRoutes = require('./api/user/user.routes');
const authRoutes = require('./api/auth/auth.routes');
const transactionRoutes = require('./api/transaction/transaction.routes');
const reportRoutes = require('./api/report/report.routes');
const errorHandlerMiddleware = require('./middlewares/error.middleware');

app.use(cors({
    origin: '*',  // Replace with your front-end origin
    methods: ['GET', 'POST', 'PUT', 'DELETE'],  // Allowed methods
    allowedHeaders: ['Content-Type', 'Authorization'],  // Allowed headers
}));
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true })); // แปลงข้อมูลแบบ URL-encoded
app.use(morgan("dev"))
app.use('/api', userRoutes);
app.use("/api", authRoutes)
app.use("/api", transactionRoutes)
app.use("/api", reportRoutes)

// Route สำหรับกรณีที่ไม่พบ Route
app.use((req, res, next) => {
    res.status(404).json({
        path: req.path,
        message: "Route not found"
    });
});

// Error Middleware ต้องมาไว้ "ท้ายสุด" หลัง route ทุกตัว
app.use(errorHandlerMiddleware);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server is running on port ${PORT}`));
