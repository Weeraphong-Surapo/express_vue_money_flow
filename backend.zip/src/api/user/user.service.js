const db = require("../../config/database");
const bcrypt = require("bcryptjs");

// Create
async function createUser(data) {
    await checkUser(data.username);
    const hashedPassword = await hashPassword(data.password);
    const payload = [data.username, data.name, hashedPassword];

    const query = `INSERT INTO user (username, name, password) VALUES (?, ?, ?)`;
    const [result] = await db.promise().query(query, payload);

    const [rows] = await db.promise().query(`SELECT id, username, name FROM user WHERE id = ?`, [result.insertId]);
    return rows[0];
}

// Read All
async function getAllUsers() {
    const [rows] = await db.promise().query(`SELECT id, username, name FROM user`);
    return rows;
}

// Read One
async function getUserById(id) {
    const [rows] = await db.promise().query(`SELECT id, username, name FROM user WHERE id = ?`, [id]);
    return rows[0];
}

// Update
async function updateUser(id, data) {
    const fields = [];
    const values = [];

    if (data.name) {
        fields.push("name = ?");
        values.push(data.name);
    }

    if (data.password) {
        const hashedPassword = await hashPassword(data.password);
        fields.push("password = ?");
        values.push(hashedPassword);
    }

    if (fields.length === 0) return await getUserById(id);

    values.push(id);
    const query = `UPDATE user SET ${fields.join(", ")} WHERE id = ?`;
    await db.promise().query(query, values);

    return await getUserById(id);
}

// Delete
async function deleteUser(id) {
    const user = await getUserById(id);
    if (!user) {
        const error = new Error("User not found!");
        error.status = 404;
        throw error;
    }
    await db.promise().query(`DELETE FROM user WHERE id = ?`, [id]);
    return user;
}

// ตรวจสอบ username ซ้ำ
async function checkUser(username) {
    const [rows] = await db.promise().query(`SELECT id FROM user WHERE username = ? LIMIT 1`, [username]);
    if (rows.length > 0) {
        const error = new Error("Username already exists.");
        error.status = 400;
        throw error;
    }
    return null;
}

// การเข้ารหัสรหัสผ่าน
async function hashPassword(plainPassword) {
    const salt = await bcrypt.genSalt(10);
    return await bcrypt.hash(plainPassword, salt);
}

module.exports = {
    createUser,
    getAllUsers,
    getUserById,
    updateUser,
    deleteUser,
    checkUser
};
