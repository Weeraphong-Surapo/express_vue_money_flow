const express = require('express');
const router = express.Router();
const upload = require('../../middlewares/upload.middleware');
const validate = require('../../middlewares/validate.middleware');
const authMiddleware = require('../../middlewares/auth.middleware');
const roleMiddleware = require('../../middlewares/role.middleware');
const userController = require('./user.controller');

const { createUserSchema, updateUserSchema } = require('../../validators/user.validator');

router.get(
    '/user',
    authMiddleware,
    roleMiddleware(['ADMIN']),
    userController.getAllUsers
);

router.post(
    '/user',
    authMiddleware,
    roleMiddleware(['ADMIN']),
    upload.single('profile'),
    validate(createUserSchema),
    userController.createUser
);

router.put(
    '/user/:id',
    authMiddleware,
    roleMiddleware(['ADMIN']),
    upload.single('profile'),
    validate(updateUserSchema),
    userController.updateUser
);

router.delete(
    '/user/:id',
    authMiddleware,
    roleMiddleware(['ADMIN']),
    userController.deleteUser
);

module.exports = router;
