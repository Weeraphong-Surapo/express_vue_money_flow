const userService = require('./user.service');

exports.createUser = async (req, res, next) => {
    try {
        await userService.createUser(req.body);
        res.json({
            message: "Created user successful!"
        });
    } catch (err) {
        next(err); // ส่ง error ไป middleware
    }
};

exports.getAllUsers = async (req, res, next) => {
    try {
        const users = await userService.getAllUsers();
        res.json(users);
    } catch (err) {
        next(err);
    }
};

exports.getUserById = async (req, res, next) => {
    try {
        const { id } = req.params;
        const user = await userService.getUserById(id);
        if (!user) {
            const error = new Error('User not found');
            error.status = 404;
            throw error;
        }
        res.json(user);
    } catch (err) {
        next(err);
    }
};

exports.updateUser = async (req, res, next) => {
    try {
        const { id } = req.params;
        const user = await userService.updateUser(id, req.body);
        res.json({ message: 'Updated user successful!' });
    } catch (err) {
        next(err);
    }
};

exports.deleteUser = async (req, res, next) => {
    try {
        const { id } = req.params;
        const user = await userService.deleteUser(id);
        res.json({ message: 'User deleted' });
    } catch (err) {
        next(err);
    }
};
