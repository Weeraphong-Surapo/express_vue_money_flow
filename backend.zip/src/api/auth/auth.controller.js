const authService = require("./auth.service")

exports.login = async (req, res, next) => {
    try {
        // return res.json(req.body)

        const user = await authService.login(req.body)
        res.json(user)
    } catch (error) {
        next(error)
    }
}

exports.register = async (req, res, next) => {
    try {
        const user = await authService.register(req.body)
        res.json({
            message: "Registerd successful!",
            user
        })
    } catch (error) {
        next(error)
    }
}

exports.profile = async (req, res, next) => {
    try {
        const userId = req.user.data.id;
        const user = await authService.profile(userId)
        res.json({
            message: "Get profile successful!",
            user
        })
    } catch (error) {
        next(error)
    }
}