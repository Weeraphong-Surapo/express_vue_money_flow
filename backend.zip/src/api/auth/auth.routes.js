const express = require("express")
const router = express.Router();
const authController = require("./auth.controller");
const validate = require("../../middlewares/validate.middleware");
const { registerSchema, loginSchema } = require("../../validators/auth.validator");
const authMiddleware = require('../../middlewares/auth.middleware');
const roleMiddleware = require('../../middlewares/role.middleware');

router.post(
    '/login',
    validate(loginSchema),
    authController.login
)

router.post(
    '/register',
    validate(registerSchema),
    authController.register
)

router.get(
    '/profile',
    authMiddleware,
    roleMiddleware(['ADMIN', 'USER']),
    authController.profile
)

module.exports = router