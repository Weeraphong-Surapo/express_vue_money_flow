const bcrypt = require('bcryptjs');
const jwt = require("jsonwebtoken");
const db = require("../../config/database"); // mysql2 connection

// 🔑 Login
async function login(data) {
    const [rows] = await db.promise().query("SELECT * FROM users WHERE username = ?", [data.username]);
    const user = rows[0];

    if (!user) {
        const error = new Error("Username not found.");
        error.status = 400;
        throw error;
    }

    const isMatch = await checkPassword(data.password, user.password);
    if (!isMatch) {
        const error = new Error("Password wrong.");
        error.status = 400;
        throw error;
    }

    const { password, ...newUser } = user;
    const token = jwt.sign(
        { data: newUser },
        'secretTokenJwt',
        { expiresIn: '1h' }
    );

    return { message: "Login successful!", user: newUser, token };
}

// 📝 Register
async function register(data) {
    const [rows] = await db.promise().query("SELECT * FROM users WHERE username = ?", [data.username]);
    const user = rows[0];

    if (user) {
        const error = new Error("Username already exists.");
        error.status = 400;
        throw error;
    }

    const hashedPassword = await hashPassword(data.password);
    const [result] = await db.promise().query(
        "INSERT INTO users (name, username, password) VALUES (?, ?, ?)",
        [data.name, data.username, hashedPassword]
    );

    const newUser = {
        id: result.insertId,
        name: data.name,
        username: data.username
    };

    return newUser;
}

// 👤 Profile
async function profile(userId) {
    const [rows] = await db.promise().query("SELECT * FROM users WHERE id = ?", [userId]);
    const user = rows[0];

    if (!user) {
        const error = new Error("User not found.");
        error.status = 404;
        throw error;
    }

    const { password, ...newUser } = user;
    return newUser;
}

// 🔐 Hash password
async function hashPassword(plainPassword) {
    const salt = await bcrypt.genSalt(10);
    return bcrypt.hash(plainPassword, salt);
}

// 🔍 Check password
async function checkPassword(plainPassword, hashedPassword) {
    return bcrypt.compare(plainPassword, hashedPassword);
}

module.exports = {
    login,
    register,
    profile
}
