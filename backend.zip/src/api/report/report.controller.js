const reportService = require("./report.service")

exports.reportDashboard = async (req, res, next) => {
    try {
        const userId = req.user.data.id;
        const { month, year } = req.query;

        const data = await reportService.reportDashboard(userId, month, year)
        res.json({
            message: "Report get successful!",
            data
        })
    } catch (error) {
        next(error)
    }
}