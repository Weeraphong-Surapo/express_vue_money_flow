const express = require("express")
const router = express.Router();
const reportController = require("./report.controller");
const authMiddleware = require('../../middlewares/auth.middleware');
const roleMiddleware = require('../../middlewares/role.middleware');

router.get(
    '/report',
    authMiddleware,
    roleMiddleware(['ADMIN', 'USER']),
    reportController.reportDashboard
)

module.exports = router