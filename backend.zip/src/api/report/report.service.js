const db = require("../../config/database");

async function reportDashboard(userId, month, year) {
    const conditions = [];
    const params = [];

    // ✅ เงื่อนไขช่วงวันที่
    if (month && year) {
        const startDate = new Date(year, month - 1, 1);
        const endDate = new Date(year, month, 1);
        conditions.push(`createdAt >= ? AND createdAt < ?`);
        params.push(startDate, endDate);
    }

    // 🔁 ฟังก์ชันสำหรับดึงข้อมูลรวมแบบ dynamic
    async function getSum(category, includeDateFilter = true) {
        const where = [`user_id = ?`, `category = ?`];
        const queryParams = [userId, category];

        if (includeDateFilter && conditions.length > 0) {
            where.push(conditions.join(" AND "));
            queryParams.push(...params);
        }

        const query = `SELECT SUM(amount) as total FROM transactions WHERE ${where.join(" AND ")}`;
        const [rows] = await db.promise().query(query, queryParams);
        return rows[0].total || 0;
    }

    // 📊 ดึงยอดรวมในเดือน
    const totalIncome = await getSum("INCOME", true);
    const totalExpense = await getSum("EXPENSE", true);
    const totalSavings = await getSum("SAVINGS", true);
    const totalInvestment = await getSum("INVESTMENT", true);

    // 📊 ดึงยอดรวมทั้งหมด
    const totalAllIncome = await getSum("INCOME", false);
    const totalAllExpense = await getSum("EXPENSE", false);
    const totalAllSavings = await getSum("SAVINGS", false);
    const totalAllInvestment = await getSum("INVESTMENT", false);

    return {
        INCOME: totalIncome,
        EXPENSE: totalExpense,
        SAVINGS: totalSavings,
        INVESTMENT: totalInvestment,

        INCOMEAll: totalAllIncome,
        EXPENSEAll: totalAllExpense,
        SAVINGSAll: totalAllSavings,
        INVESTMENTAll: totalAllInvestment,
    };
}

module.exports = {
    reportDashboard
};
