const transactionService = require("./transaction.service")

exports.getAllTransaction = async (req, res, next) => {
    try {
        const userId = req.user.data.id;
        const { month, year, category } = req.query;

        const transactions = await transactionService.getAllTransaction(userId, month, year, category);
        res.json(transactions);
    } catch (error) {
        next(error)
    }
}

exports.getTransaction = async (req, res, next) => {
    try {
        const { id } = req.params
        const transactions = await transactionService.getTransaction(id);
        res.json(transactions);
    } catch (error) {
        next(error)
    }
}

exports.createTransaction = async (req, res, next) => {
    try {
        const userId = req.user.data.id;


        const transaction = await transactionService.createTransaction(req.body, userId)
        res.json({
            message: "Created transaction successful!",
            transaction
        })
    } catch (error) {
        next(error)
    }
}

exports.updateTransaction = async (req, res, next) => {
    try {
        const userId = req.user.data.id;
        const { id } = req.params

        const transaction = await transactionService.updateTransaction(req.body, id, userId)
        res.json({
            message: "Updated transaction successful!",
            transaction
        })
    } catch (error) {
        next(error)
    }
}
exports.deleteTransaction = async (req, res, next) => {
    try {
        const { id } = req.params

        const transaction = await transactionService.deleteTransaction(id)
        res.json({
            message: "Deleted transaction successful!",
        })
    } catch (error) {
        next(error)
    }
}