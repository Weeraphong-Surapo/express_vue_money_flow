const db = require("../../config/database");

async function getAllTransaction(userId, month, year, category) {
    const conditions = [`user_id = ?`];
    const params = [userId];

    if (month && year) {
        const startDate = new Date(year, month - 1, 1);
        const endDate = new Date(year, month, 1);
        conditions.push(`createdAt >= ? AND createdAt < ?`);
        params.push(startDate, endDate);
    }

    if (category) {
        conditions.push(`category = ?`);
        params.push(category);
    }

    const query = `SELECT * FROM transaction WHERE ${conditions.join(" AND ")} ORDER BY createdAt DESC`;
    const [rows] = await db.promise().query(query, params);
    return rows;
}

async function getTransaction(id) {
    const query = `SELECT * FROM transaction WHERE id = ? LIMIT 1`;
    const [rows] = await db.promise().query(query, [id]);
    return rows[0];
}

async function createTransaction(data, userId) {
    const query = `INSERT INTO transaction (amount, category, title, user_id) VALUES (?, ?, ?, ?)`;
    const [result] = await db.promise().query(query, [
        data.amount,
        data.category,
        data.title,
        userId
    ]);

    const [newTransaction] = await db.promise().query(`SELECT * FROM transaction WHERE id = ?`, [result.insertId]);
    return newTransaction[0];
}

async function updateTransaction(data, id, userId) {
    const query = `
        UPDATE transaction 
        SET amount = ?, category = ?, title = ?, user_id = ?
        WHERE id = ?
    `;
    await db.promise().query(query, [
        data.amount,
        data.category,
        data.title,
        userId,
        id
    ]);

    const [updated] = await db.promise().query(`SELECT * FROM transaction WHERE id = ?`, [id]);
    return updated[0];
}

async function deleteTransaction(id) {
    const [transaction] = await db.promise().query(`SELECT * FROM transaction WHERE id = ?`, [id]);
    await db.promise().query(`DELETE FROM transaction WHERE id = ?`, [id]);
    return transaction[0];
}

module.exports = {
    getAllTransaction,
    createTransaction,
    updateTransaction,
    deleteTransaction,
    getTransaction
};
