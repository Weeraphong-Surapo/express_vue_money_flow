const express = require("express")
const router = express.Router();
const transactionController = require("./transaction.controller");
const validate = require("../../middlewares/validate.middleware");
const authMiddleware = require('../../middlewares/auth.middleware');
const roleMiddleware = require('../../middlewares/role.middleware');
const { createTransactionSchema } = require("../../validators/transaction.validator");

router.get(
    '/transaction',
    authMiddleware,
    roleMiddleware(['ADMIN', 'USER']),
    transactionController.getAllTransaction
)

router.get(
    '/transaction/:id',
    authMiddleware,
    roleMiddleware(['ADMIN', 'USER']),
    transactionController.getTransaction
)

router.post(
    '/transaction',
    authMiddleware,
    roleMiddleware(['ADMIN', 'USER']),
    validate(createTransactionSchema),
    transactionController.createTransaction
)

router.put(
    '/transaction/:id',
    authMiddleware,
    roleMiddleware(['ADMIN', 'USER']),
    validate(createTransactionSchema),
    transactionController.updateTransaction
)

router.put(
    '/transaction/:id',
    authMiddleware,
    roleMiddleware(['ADMIN', 'USER']),
    validate(createTransactionSchema),
    transactionController.updateTransaction
)

router.delete(
    '/transaction/:id',
    authMiddleware,
    roleMiddleware(['ADMIN', 'USER']),
    transactionController.deleteTransaction
)


module.exports = router