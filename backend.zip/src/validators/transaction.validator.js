
const createTransactionSchema = [
    { name: 'amount', required: true, type: 'number' },
    { name: 'category', required: true, type: 'string' },
    { name: 'title', required: true, type: 'string' },
];

module.exports = {
    createTransactionSchema,
};
