// validators/user.validator.js

const createUserSchema = [
    { name: 'username', required: true, type: 'string', minLength: 6, maxLength: 255 },
    { name: 'name', required: true, type: 'string', minLength: 6, maxLength: 255 },
    { name: 'password', required: true, type: 'string', minLength: 6, maxLength: 255 },
];

const updateUserSchema = [
    { name: 'username', required: true, type: 'string', maxLength: 255 },
    { name: 'name', required: true, type: 'string', maxLength: 255 },
];

module.exports = {
    createUserSchema,
    updateUserSchema,
};
