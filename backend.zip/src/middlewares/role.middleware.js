function roleMiddleware(roles = []) {
    return (req, res, next) => {
      if (!req.user) {
        return res.status(401).json({ error: 'Unauthorized' });
      }
  
    //   console.log(req.user);
      
      if (!roles.includes(req.user.data.role)) {
        return res.status(403).json({ error: 'Forbidden: No permission' });
      }
  
      next();
    };
  }
  
  module.exports = roleMiddleware;
  