const fs = require('fs');
const path = require('path');

function getNestedValue(obj, path) {
  const keys = path.split('.');
  return keys.reduce((acc, key) => (acc && acc[key] !== undefined ? acc[key] : undefined), obj);
}

function validate(fields) {
  return (req, res, next) => {
    const errors = {};

    for (const field of fields) {
      const value = getNestedValue(req.body, field.name);

      // Check required
      if (field.required && (value === undefined || value === '' || value === null)) {
        errors[field.name] = `${field.name} is required`;
        continue; // ถ้า required ไม่ผ่าน ไม่ต้องเช็กอย่างอื่น
      }

      if (value !== undefined) {
        // Type checking
        if (field.type === 'email') {
          const emailRegex = /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/;
          if (typeof value !== 'string' || !emailRegex.test(value)) {
            errors[field.name] = `${field.name} must be a valid email`;
          }
        }

        if (field.type === 'string') {
          if (typeof value !== 'string') {
            errors[field.name] = `${field.name} must be a string`;
          } else {
            if (field.minLength && value.length < field.minLength) {
              errors[field.name] = `${field.name} must be at least ${field.minLength} characters`;
            }
            if (field.maxLength && value.length > field.maxLength) {
              errors[field.name] = `${field.name} must be less than ${field.maxLength} characters`;
            }
          }
        }

        if (field.type === 'number') {
          const numberValue = Number(value);
          if (isNaN(numberValue)) {
            errors[field.name] = `${field.name} must be a number`;
          } else {
            if (field.integer && !Number.isInteger(numberValue)) {
              errors[field.name] = `${field.name} must be an integer`;
            }
            if (field.positive && numberValue <= 0) {
              errors[field.name] = `${field.name} must be a positive number`;
            }
            if (field.min !== undefined && numberValue < field.min) {
              errors[field.name] = `${field.name} must be greater than or equal to ${field.min}`;
            }
            if (field.max !== undefined && numberValue > field.max) {
              errors[field.name] = `${field.name} must be less than or equal to ${field.max}`;
            }
          }
        }

        if (field.type === 'array') {
          let arr;
          try {
            arr = typeof value === 'string' ? JSON.parse(value) : value;
          } catch (error) {
            arr = null;
          }
          if (!Array.isArray(arr)) {
            errors[field.name] = `${field.name} must be an array`;
          } else {
            if (field.minLength && arr.length < field.minLength) {
              errors[field.name] = `${field.name} must have at least ${field.minLength} items`;
            }
            if (field.maxLength && arr.length > field.maxLength) {
              errors[field.name] = `${field.name} must have less than ${field.maxLength} items`;
            }
          }
        }
      }
    }

    // ถ้ามี error
    if (Object.keys(errors).length > 0) {
      if (req.file) {
        const filePath = path.join(__dirname, '../../uploads', req.file.filename);
        fs.unlink(filePath, (err) => {
          if (err) {
            console.error('Failed to delete uploaded file:', err);
          }
        });
      }

      return res.status(400).json({ errors });
    }

    next();
  };
}

module.exports = validate;
