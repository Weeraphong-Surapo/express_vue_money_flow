// stores/counter.js
import { defineStore } from 'pinia'

export const useAuthStore = defineStore('authStore', {
    state: () => {
        return {
            user: null
        }
    },
    actions: {
        async profile() {
            const res = await fetch("/api/profile", {
                headers: {
                    Authorization: `Bearer ${localStorage.getItem("token")}`
                }
            })
            const {user} = await res.json()
    
            this.user = user
        }
    },
})