<template>
    <div>
        <Header/>
        <router-view></router-view>
    </div>
</template>

<script setup>
import Header from '@/components/Header.vue';

</script>

<style lang="scss" scoped>

</style>