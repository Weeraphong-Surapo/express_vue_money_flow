<template>
    <div class="container py-4">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><router-link to="/">หน้าแรก</router-link></li>
                <li class="breadcrumb-item active" aria-current="page">สร้างรายการ</li>
            </ol>
        </nav>
        <form @submit.prevent="handleSubmit">
            <div class="mb-3">
                <label for="">ประเภท</label>
                <select class="form-select" @change="selectCategory">
                    <option value="" disabled selected>-- เลือกประเภท --</option>
                    <option value="INCOME">-- รายรับ --</option>
                    <option value="EXPENSE">-- รายจ่าย --</option>
                    <option value="SAVINGS">-- เงินออม --</option>
                    <option value="INVESTMENT">-- ลงทุน --</option>
                </select>
                <small class="text-danger" v-if="errors.category">{{ errors.category }}</small>
            </div>
            <div class="mb-3">
                <label for="">รายการ</label>
                <input type="text" class="form-control" v-model="formData.title">
                <small class="text-danger" v-if="errors.title">{{ errors.title }}</small>
            </div>
            <div class="mb-3">
                <label for="">จำนวนเงิน</label>
                <input type="text" class="form-control" v-model="formData.amount">
                <small class="text-danger" v-if="errors.amount">{{ errors.amount }}</small>
            </div>
            <button class="btn btn-success" :disabled="loadingBtn">{{ loadingBtn ? 'กำลังบันทึก...' : 'บันทึก' }}</button>
        </form>
    </div>
</template>

<script setup>
import { createTransaction } from '@/api/transaction';
import { ref } from 'vue';
import Swal from 'sweetalert2'
import { useRouter } from 'vue-router';


const router = useRouter()
const loadingBtn = ref(false)
const errors = ref({})
const formData = ref({
    category: "",
    title: "",
    amount: "",
})

function selectCategory(e) {
    const { value } = e.target
    formData.value.category = value
}

async function handleSubmit() {
    try {
        loadingBtn.value = true
        const res = await createTransaction(formData.value)
        if (res.errors) {
            errors.value = res.errors
        } else if (res.error) {
            errors.value = {
                errorTop: res.error
            }
        } else {
            Swal.fire({
                title: 'สำเร็จ!',
                text: 'บันทึกข้อมูลเรียบร้อยแล้ว',
                icon: 'success',
                confirmButtonText: 'ตกลง'
            })
            router.push('/')

        }

    } catch (error) {
        console.log(error);
    } finally {
        loadingBtn.value = false
    }
}
</script>

<style lang="scss" scoped></style>