<template>
    <div class="d-flex justify-content-center align-items-center vh-100 bg-primary">
        <div class="card">
            <div class="card-header">ยินดีต้อนรับเข้าสู่ระบบ MONEY-FLOW</div>
            <div class="card-body">
                <ul class="bg-danger m-0 text-white rounded" v-if="errors.errorTop">
                    <li class="p-2 ">{{ errors.errorTop }}</li>
                </ul>
                <form @submit.prevent="handleSubmit" class="px-4 py-3">
                    <div class="mb-3">
                        <label for="">ชื่อผู้ใช้งาน</label>
                        <input type="text" class="form-control" v-model="formData.username">
                        <small v-if="errors.username" class="text-danger">{{ errors.username }}</small>
                    </div>
                    <div class="mb-3">
                        <label for="">รหัสผ่าน</label>
                        <input type="text" class="form-control" v-model="formData.password">
                        <small v-if="errors.password" class="text-danger">{{ errors.password }}</small>
                    </div>
                    <button class="btn btn-primary w-100 mb-3" :disabled="loadingBtn">{{ loadingBtn ? 'เข้าสู่ระบบ...' :
                        'เข้าสู่ระบบ' }}</button>
                    <span>ยังไม่บัญชีใช่ไหม? <router-link :to="{ name: 'register' }">สมัครสมาชิก</router-link></span>
                </form>
            </div>
        </div>
    </div>
</template>

<script setup>
import { login } from '@/api/auth';
import { ref } from 'vue';
import { useRouter } from 'vue-router';
import Swal from 'sweetalert2'

const router = useRouter()

const loadingBtn = ref(false)
const formData = ref({
    username: "",
    password: ""
})
const errors = ref({})

async function handleSubmit() {
    try {
        loadingBtn.value = true
        const res = await login(formData.value)
        if (res.errors) {
            errors.value = res.errors
        } else if (res.error) {
            errors.value = {
                errorTop: res.error
            }
        } else {
            Swal.fire({
                title: 'สำเร็จ!',
                text: 'เข้าสู่ระบบสำเร็จ!',
                icon: 'success',
                confirmButtonText: 'ตกลง'
            })
            localStorage.setItem("token", res.token)
            router.push('/')
        }
    } catch (error) {
        console.log(error);
    } finally {
        loadingBtn.value = false
    }
}
</script>

<style lang="scss" scoped></style>