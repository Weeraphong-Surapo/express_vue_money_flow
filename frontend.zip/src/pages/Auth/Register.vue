<template>
    <div class="d-flex justify-content-center align-items-center vh-100 bg-primary">
        <div class="card">
            <!-- {{ errors }} -->
            <div class="card-header">ยินดีต้อนรับเข้าสู่ระบบ MONEY-FLOW</div>
            <div class="card-body">
                <form @submit.prevent="handleSubmit" class="px-4 py-3">
                    <div class="mb-3">
                        <label for="">ชื่อ - สกุล</label>
                        <input type="text" class="form-control" v-model="formData.name">
                        <small v-if="errors.name" class="text-danger">{{ errors.name }}</small>
                    </div>
                    <div class="mb-3">
                        <label for="">ชื่อผู้ใช้งาน</label>
                        <input type="text" class="form-control" v-model="formData.username">
                        <small v-if="errors.username" class="text-danger">{{ errors.username }}</small>
                    </div>
                    <div class="mb-3">
                        <label for="">รหัสผ่าน</label>
                        <input type="text" class="form-control" v-model="formData.password">
                        <small v-if="errors.password" class="text-danger">{{ errors.password }}</small>
                    </div>
                    <button class="btn btn-primary w-100 mb-3" :disabled="loadingBtn">{{ loadingBtn ? 'สมัครมาชิก...' :
                        'สมัครมาชิก' }}</button>
                    <span>มีบัญชีแล้วใช่ไหม? <router-link :to="{ name: 'login' }"
                            class="">เข้าสู่ระบบ</router-link></span>
                </form>
            </div>
        </div>
    </div>
</template>

<script setup>
import { register } from '@/api/auth';
import { ref } from 'vue';
import Swal from 'sweetalert2'
import { useRouter } from 'vue-router';

const router = useRouter()
const formData = ref({
    name: "",
    username: "",
    password: ""
})
const errors = ref({})

async function handleSubmit() {
    try {
        const res = await register(formData.value)
        if (res.errors) {
            errors.value = res.errors
        } else if (res.error) {
            errors.value = res.error
        } else {
            Swal.fire({
                title: 'สำเร็จ!',
                text: 'สมัครสามชิกสำเร็จ!',
                icon: 'success',
                confirmButtonText: 'ตกลง'
            })
            router.push("/login")
        }
    } catch (error) {
        console.log(error);
    }
}
</script>

<style lang="scss" scoped></style>