<template>
    <div class="container py-4">
        <Loader v-if="loading" />
        <div v-else>
            <div class="row">
                <div class="col-md-8">
                    <h5 class="text-center alert alert-secondary">ภาพรวมเดือน {{ month }} - {{ year+543 }}</h5>
                    <apexchart type="pie" height="200" :options="chartOptions" :series="series" />
                </div>
                <!-- {{ dataDashboard }} -->
                <div class="col-md-4">
                    <h5 class="text-center alert alert-secondary">ภาพรวมทั้งหมด</h5>
                    <ul class="list-unstyled">
                        <li class="d-flex justify-content-between p-1 p-1">
                            <span>รายได้รวม</span>
                            <span>{{ dataDashboard.INCOMEAll }}</span>
                        </li>
                        <li class="d-flex justify-content-between p-1">
                            <span>รายจ่ายรวม</span>
                            <span>{{ dataDashboard.EXPENSEAll }}</span>
                        </li>
                        <li class="d-flex justify-content-between bg-success text-white p-1">
                            <span>คงเหลือ</span>
                            <span>{{ dataDashboard.INCOMEAll - dataDashboard.EXPENSEAll }}</span>
                        </li>
                        <li class="d-flex justify-content-between p-1">
                            <span>เงินออม</span>
                            <span>{{ dataDashboard.SAVINGSAll }}</span>
                        </li>
                        <li class="d-flex justify-content-between p-1">
                            <span>ลงทุน</span>
                            <span>{{ dataDashboard.INVESTMENTAll }}</span>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="row mb-2">
                <div class="col-md-6">
                    <label for="">เดือน</label>
                    <select name="" id="" class="form-select" @change="selectMonth">
                        <option value="" disabled selected>-- เลือกเดือน --</option>
                        <option value="1" :selected="month == 1">-- มกราคม --</option>
                        <option value="2" :selected="month == 2">-- กุมภาพันธ์ --</option>
                        <option value="3" :selected="month == 3">-- มีนาคม --</option>
                        <option value="4" :selected="month == 4">-- เมษายน --</option>
                        <option value="5" :selected="month == 5">-- พฤษภาคม --</option>
                        <option value="6" :selected="month == 6">-- มิถุนายน --</option>
                        <option value="7" :selected="month == 7">-- กรกฏาคม --</option>
                        <option value="8" :selected="month == 8">-- สิงหาคม --</option>
                        <option value="9" :selected="month == 9">-- กันยายน --</option>
                        <option value="10" :selected="month == 10">-- ตุลาคม --</option>
                        <option value="11" :selected="month == 11">-- พฤศจิกายน --</option>
                        <option value="12" :selected="month == 12">-- ธันวาคม --</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <label for="">ปี</label>
                    <select name="" id="" class="form-select" @change="selectYear">
                        <option value="" disabled selected>-- เลือกปี --</option>
                        <option value="2024" :selected="year == 2024">-- 2567 --</option>
                        <option value="2025" :selected="year == 2025">-- 2568 --</option>
                        <option value="2026" :selected="year == 2026">-- 2569 --</option>
                        <option value="2027" :selected="year == 2027">-- 2570 --</option>
                    </select>
                </div>
            </div>

            <div class="btn-group d-flex justify-content-center mb-2">
                <button class="btn btn-primary" @click="selectCategory('')">ทั้งหมด</button>
                <button class="btn btn-success" @click="selectCategory('INCOME')">รายรับ</button>
                <button class="btn btn-danger" @click="selectCategory('EXPENSE')">รายจ่าย</button>
                <button class="btn btn-info" @click="selectCategory('SAVINGS')">เงินออม</button>
                <button class="btn btn-warning" @click="selectCategory('INVESTMENT')">ลงทุน</button>
            </div>
            <div class="d-flex justify-content-center">
                <router-link :to="{ name: 'create' }" class="btn btn-secondary mb-3">เพิ่มข้อมูล</router-link>
            </div>
            <h6 class="text-center">{{ categoryShow }}</h6>
            <div class="table-responsive">
                <vue-good-table :columns="columns" :rows="transactions" :search-options="{
                    enabled: true,
                    skipDiacritics: true,
                    placeholder: 'ค้นหาข้อมูล...',
                }" :pagination-options="{
                    enabled: true,
                    mode: 'records',
                    perPage: 5,
                    position: 'top',
                    perPageDropdown: [3, 7, 9],
                    dropdownAllowAll: false,
                    setCurrentPage: 1,
                    jumpFirstOrLast: true,
                    firstLabel: 'First Page',
                    lastLabel: 'Last Page',
                    nextLabel: 'ถัดไป',
                    prevLabel: 'ก่อนหน้า',
                    rowsPerPageLabel: 'ข้อมูลต่อหน้า',
                    ofLabel: 'of',
                    pageLabel: 'page', // for 'pages' mode
                    allLabel: 'All',
                    infoFn: (params) => `อยู่ที่หน้า ${params.firstRecordOnPage}`,
                }">
                    <template v-slot:table-row="props">
                        <span v-if="props.column.field === 'action'" class="btn-group">
                            <router-link :to="{ name: 'update', params: { id: props.row.id } }"
                                class="btn btn-sm btn-warning">✏️</router-link>
                            <button class="btn btn-sm btn-danger" @click="confirmDelete(props.row)">🗑️</button>
                        </span>
                        <span v-else-if="props.column.field === 'createdAt'">
                            {{ formatDate(props.row.createdAt) }}
                        </span>
                        <span v-else-if="props.column.field === 'category'">
                            <span :class="{
                                'badge text-bg-success': props.row.category === 'INCOME',
                                'badge text-bg-danger': props.row.category === 'EXPENSE',
                                'badge text-bg-info': props.row.category === 'SAVINGS',
                                'badge text-bg-warning': props.row.category === 'INVESTMENT',
                            }">{{ translateCategory(props.row.category) }}</span>
                        </span>
                        <span v-else>
                            {{ props.formattedRow[props.column.field] }}
                        </span>
                    </template>
                </vue-good-table>
            </div>
        </div>
    </div>
</template>

<script setup>
import { VueGoodTable } from 'vue-good-table-next' // นำเข้า component
import { getAllTransactions, deleteTransaction } from '@/api/transaction'
import { getReportDashboard } from '@/api/report'
import { onMounted, ref } from 'vue'
import Loader from '@/components/Loader.vue'
import moment from 'moment'
import 'moment/dist/locale/th' // ✅ ต้อง import แบบนี้ (Vite ต้องใช้ dist/locale ด้วย)
import Swal from 'sweetalert2';

moment.locale('th') // ตั้งค่า locale เป็นภาษาไทย

const year = ref(new Date().getFullYear())
const month = ref(new Date().getMonth() + 1)
const loading = ref(true)
const transactions = ref([])
const dataDashboard = ref({})
const categoryShow = ref('')

const columns = ref([
    { label: 'รายการ', field: 'title' },
    { label: 'จำนวน', field: 'amount' },
    { label: 'ประเภท', field: 'category' },
    { label: 'วันที่', field: 'createdAt' },
    { label: '#', field: 'action' },
])
// 📌 ข้อมูลของ Pie Chart ต้องเป็นตัวเลขเรียงตรง ๆ
const series = ref([]) // ✅

const chartOptions = {
    labels: ['INCOME', 'EXPENSE', 'SAVINGS', 'INVESTMENT'], // ✅ Label ต้องมี
    chart: {
        type: 'pie',
    },
}

async function confirmDelete(row) {
    const result = await Swal.fire({
        title: 'คุณแน่ใจหรือไม่?',
        text: 'ข้อมูลนี้จะถูกลบอย่างถาวร!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'ใช่, ลบเลย!',
        cancelButtonText: 'ยกเลิก',
        reverseButtons: true
    });

    if (result.isConfirmed) {
        // ✅ ทำการลบข้อมูล
        await deleteTransaction(row);
        Swal.fire('ลบแล้ว!', 'ข้อมูลถูกลบเรียบร้อยแล้ว', 'success');
        await loadData(month.value, year.value, '')
    }
}

function translateCategory(category) {
    switch (category) {
        case 'INCOME':
            return 'รายรับ';
        case 'EXPENSE':
            return 'รายจ่าย';
        case 'SAVINGS':
            return 'เงินออม';
        case 'INVESTMENT':
            return 'ลงทุน';
        default:
            return category; // ถ้าไม่มีตรงเงื่อนไข ส่งค่าปกติกลับ
    }
}

async function selectCategory(category) {
    categoryShow.value = category
    await loadData(month.value, year.value, category)

}

function formatDate(date) {
    return moment(date)
        .add(543, 'years')
        .format('D MMMM YYYY')
}

function selectYear(e) {
    const { value } = e.target
    year.value = value
    loadData(month.value, value, '')

}

function selectMonth(e) {
    const { value } = e.target
    month.value = value
    loadData(value, year.value, '')

}

async function loadData(getMonth = '', getYear = '', getCategory = '') {
    try {
        loading.value = true
        transactions.value = await getAllTransactions(getMonth, getYear, getCategory)
        const { data } = await getReportDashboard(getMonth, getYear)
        dataDashboard.value = data
        series.value = [
            // 234,234,234,234
            Number(data.INCOME) || 0,
            Number(data.EXPENSE) || 0,
            Number(data.SAVINGS) || 0,
            Number(data.INVESTMENT) || 0
        ]
    } catch (error) {
        console.log(error);

    } finally {
        loading.value = false
    }
}

onMounted(() => {
    loadData(month.value, year.value, '')
})
</script>