import { createWebHistory, createRouter } from 'vue-router'

import routes from "./routes"
import { useAuthStore } from '../stores/auth'

const router = createRouter({
    history: createWebHistory(),
    routes,
})

// ✅ Middleware: ตรวจสอบการเข้าสู่ระบบ
router.beforeEach(async (to, from, next) => {
    const authStore = useAuthStore()
    await authStore.profile()

    if (to.meta.requiresAuth && !authStore.user) {
        next({ name: 'login' }); // เปลี่ยนเส้นทางไปหน้า login
    } else if (!to.meta.requiresAuth && authStore.user) {
        next({ name: 'home' }); // เปลี่ยนเส้นทางไปหน้า login

    } else {
        next(); // ไปต่อได้
    }
})

export default router