export default [
    {
        path: "/login",
        name: "login",
        component: () => import("@/pages/Auth/Login.vue")
    },
    {
        path: "/register",
        name: "register",
        component: () => import("@/pages/Auth/Register.vue")
    },
    {
        path: "/",
        component: () => import("@/layouts/DefaultLayout.vue"),
        meta: { requiresAuth: true },
        children: [
            {
                path: "",
                name: "home",
                component: () => import("@/pages/Home.vue"),

            },
            {
                path: "/create",
                name: "create",
                component: () => import("@/pages/Create.vue"),

            },
            {
                path: "/update/:id",
                name: "update",
                component: () => import("@/pages/Update.vue"),

            }
        ]
    }
]