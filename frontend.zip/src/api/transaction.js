export const getAllTransactions = async (month, year, category) => {
    const res = await fetch(`/api/transaction?month=${month}&year=${year}&category=${category}`, {
        headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`
        }
    })

    const data = await res.json()
    return data;
}

export const getTransaction = async (id) => {
    const res = await fetch(`/api/transaction/${id}`, {
        headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`
        }
    })

    const data = await res.json()
    return data;
}

export const createTransaction = async (formData) => {
    const res = await fetch("/api/transaction", {
        method: "POST",
        headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`
        },
        body: JSON.stringify(formData)
    })

    const data = await res.json()
    return data;
}

export const updateTransaction = async (formData) => {
    const res = await fetch(`/api/transaction/${formData.id}`, {
        method: "PUT",
        headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`
        },
        body: JSON.stringify(formData)
    })

    const data = await res.json()
    return data;
}

export const deleteTransaction = async (row) => {
    const res = await fetch(`/api/transaction/${row.id}`, {
        method: "DELETE",
        headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`
        },
    })

    const data = await res.json()
    return data;
}