export const login = async (formData) => {
    const res = await fetch("/api/login", {
        method: "POST",
        body: JSON.stringify(formData)
    })
    const data = await res.json()
    return data
}

export const register = async (formData) => {
    const res = await fetch("/api/register", {
        method: "POST",
        body: JSON.stringify(formData)
    })
    const data = await res.json()
    return data
}