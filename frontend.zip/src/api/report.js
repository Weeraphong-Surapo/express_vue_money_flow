export const getReportDashboard = async (month, year) => {
    const res = await fetch(`/api/report?month=${month}&year=${year}`, {
        headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`
        }
    })

    const data = await res.json()
    return data;
}