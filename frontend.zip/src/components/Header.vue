<template>
    <div>
        <nav class="navbar navbar-expand-md bg-body-tertiary">
            <div class="container-fluid">
                <router-link class="navbar-brand" :to="{ name: 'home' }">MONKEY FLOW</router-link>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText"
                    aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarText">
                    <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <button class="btn btn-outline-danger" @click="logout">ออกจากระบบ</button>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </div>
</template>

<script setup>
import { useRouter } from 'vue-router';
import Swal from 'sweetalert2'

const router = useRouter()
function logout() {
    localStorage.removeItem("token")
    Swal.fire({
        title: 'สำเร็จ!',
        text: 'ออกจากระบบสำเร็จ!',
        icon: 'success',
        confirmButtonText: 'ตกลง'
    })
    router.push("/login")
}
</script>

<style lang="scss" scoped></style>