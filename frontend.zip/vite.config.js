import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import path from 'path' // <-- ต้อง import path ด้วย

export default defineConfig({
  plugins: [vue()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'), // ตั้งค่า @ ให้ชี้ไปที่ src/
    },
  },
  server: {
    proxy: {
      // ตัวอย่างการตั้งค่า Proxy สำหรับ API
      '/api': {
        target: 'https://apimoney3.shopcurations.shop', // URL ของเซิร์ฟเวอร์ที่ต้องการให้ Proxy
        changeOrigin: true,
        // rewrite: (path) => path.replace(/^\/api/, ''), // ลบ /api ออก
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json"
        }
      },
    },
  }
})
